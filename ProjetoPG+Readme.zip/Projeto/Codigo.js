function setup() {//funcao que ajeita o tamanho do canvas
    var w = window,
        d = document,
        e = d.documentElement,
        g = d.getElementsByTagName('body')[0],
        x = w.innerWidth || e.clientWidth || g.clientWidth,
        y = w.innerHeight || e.clientHeight || g.clientHeight;
    g.innerHTML += '<canvas id="canvas" width="' + (x - 15) + '" height="' + (y - 30) + '"></canvas>';
}
//operacoes base com pontos
class Ponto{
    constructor(x,y){
        this.x=x;
        this.y=y;
    }
}

function pontoSoma(p0,p1) {
    let p = new Ponto(p0.x + p1.x, p0.y + p1.y);
    return p;
}

function pontoSub(p0,p1){
    let p = new Ponto(p0.x-p1.x, p0.y - p1.y);
    return p;
}

function pontoMult(t,p0){
    let p = new Ponto(t*p0.x, t * p0.y);
    return p;
}

function normaVetor(v){
    let norma = Math.sqrt((v.x*v.x) + (v.y*v.y));
    return norma;
}

//algoritmo para encontrar os pontos da curva
function deCasteljau(pontos, t){
    if(pontos.length === 0){
        return null;
    }
    if(pontos.length === 1){
        return pontos[0];
    }
    var newpoints = [];
    for(let i=0; i<(pontos.length-1);i++){
        let p0 = pontoMult(1-t,pontos[i]);
        let p1 = pontoMult(t,pontos[i+1]);
        let p = pontoSoma(p0,p1);
        newpoints.push(p);
    }
    return deCasteljau(newpoints, t);
}

/*funcao que dados os pontos de controle e o número de iteracoes vai controlar o algoritmo
de decasteljau para criar o array dos pontos da curva a serem ligados.*/
function criarCurva(pontos, iteracoes){
    let curva = [];
    if(pontos.length===0){
        return curva;
    }
    for(let i=0; i<=iteracoes; i++){
        curva.push(deCasteljau(pontos,i/iteracoes));
    }
    return curva;
}

//funcao que faz as linhas entre os pontos de um array
function drawLinhas(pontos, cor){

    if(pontos.length !== 0){
        ctx.strokeStyle = cor;
        ctx.lineWidth = 2;
        ctx.beginPath();
        ctx.moveTo(pontos[0].x, pontos[0].y);
        for(let i=1; i<pontos.length; i++) {
            ctx.lineTo(pontos[i].x, pontos[i].y);
        }
        ctx.stroke();
    }
}

//funcao que vai pintar os pontos
function drawPontos(pontos, corP){
    ctx.fillStyle = corP;
    for(let i=0;i<pontos.length; i++){
        ctx.beginPath();
        ctx.moveTo(pontos[i].x,pontos[i].y);
        ctx.arc(pontos[i].x, pontos[i].y, 6, 0,2*Math.PI);
        ctx.fill();
    }
}

//funcao que controla os desenhos
function draw(){
    ctx.clearRect(0,0, canvas.width, canvas.height);
    let iteracoes = entrada[0].value;
    let printP = entrada[1].checked;
    let printL = entrada[2].checked;
    let printC = entrada[3].checked;
    if(printP){
        drawPontos(pontos, "#f00");
    }
    if(printL){
        drawLinhas(pontos, "#00f");
    }
    if(printC){
        let curva = criarCurva(pontos, iteracoes);
        drawLinhas(curva, "#FF0");
    }
}

//funcao que verifica se a distancia do clique para a de um ponto é grande o suficiente(clicado no vazio)
function clicadoAT(click, ponto){
    return (normaVetor(pontoSub(click,ponto))<= 12);
}

//funcao que vai verificar se o clique foi no vazio ou num ponto
function sClick(click, pontos){
    for(let i=0; i<pontos.length;i++){
        if(clicadoAT(click, pontos[i])){
            return i;
        }
    }
    return -1;
}

//botao para reiniciar os desenhos
function btnReset() {
    pontos = [];
    draw();

}

//funcao que reduz o grau da curva deixando ela "parecida" com a original na medida do possivel
function reduzirG() {
    if(pontos.length<=1){
        pontos=[];
    }
    else if(pontos.length===2 | pontos.length ===3){
        pontos.splice(1,1);
    }
    else if(pontos.length>3){
        var menor = normaVetor(pontoSub(pontos[1],pontos[2]));
        var menorI = 1;
        for(i=2;i<pontos.length-2;i++){
            if(menor>normaVetor(pontoSub(pontos[i],pontos[i+1]))){
                menorI = i;
                menor = normaVetor(pontoSub(pontos[i],pontos[i+1]));
            }
        }
        let t=1/2;
        pontos[menorI] = pontoSoma(pontoMult(1-t,pontos[menorI]), pontoMult(t,pontos[menorI+1]));
        pontos.splice(menorI+1,1);
    }
    draw();
}

//main
setup();
var body = document.getElementsByTagName("body")[0];
var entrada = document.getElementsByTagName("input");
var canvas = document.getElementById("canvas");
var ctx = canvas.getContext("2d");
var pontos = [];
var mouse = new Ponto(0,0);
var clicado;
var mover = false;
for(let i=0; i<entrada.length;i++) {
    entrada[i].addEventListener("input", e=>{draw();});
    entrada[i].addEventListener("change",e=>{draw();});
}
canvas.addEventListener("mousedown", e=>{
    clicado = sClick(mouse, pontos);
    if (clicado===-1){
        pontos.push(mouse);
    }else if(entrada[1].checked){
        mover = true;
    }
    draw();
});

canvas.addEventListener("mouseup", e=>{
    mover =false;
});


canvas.addEventListener("mousemove", e=>{
   mouse = new Ponto(e.offsetX, e.offsetY);
   if(mover && entrada[1].checked){
       pontos[clicado] = mouse;
       draw();
   }
});

canvas.addEventListener("dblclick", e=>{
    if(clicado !== -1 && entrada[1].checked){
        pontos.splice(clicado, 1);
        draw();
    }
});


